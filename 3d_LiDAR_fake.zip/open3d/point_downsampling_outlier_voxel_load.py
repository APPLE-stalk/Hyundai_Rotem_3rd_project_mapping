import pyvista as pv
import numpy as np
import matplotlib.pyplot as plt

import open3d as o3d
# point cloud ply파일 불러오기 파일 불러오기
pcd = o3d.io.read_point_cloud("downsampling_outliner_point_cloud_1.0.ply")

# 좌표축 프레임 생성 (origin 기준, 길이=1.0)
axis = o3d.geometry.TriangleMesh.create_coordinate_frame(size=1.0, origin=[0, 0, 0])

# point cloud 시각화
# o3d.visualization.draw_geometries([pcd, axis])


# point to voxel로 변환 무지개
# voxel_grid = o3d.geometry.VoxelGrid.create_from_point_cloud(pcd, voxel_size=0.5)


voxel_size = 1.0  # 원하는 voxel 크기 지정 (단위: meter)
voxel_grid = o3d.geometry.VoxelGrid.create_from_point_cloud(pcd, voxel_size=voxel_size)

# voxel 시각화 (흑색)
o3d.visualization.draw_geometries([voxel_grid])


# 색칠해서 시각화
